package cl.awakelab.Evaluacion_Modulo5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvaluacionModulo5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
