package cl.awakelab.Evaluacion_Modulo5.servicio;

public interface IAdicionalService<E> {
	
	public E findbyUsuarioRunUsuario(Integer dato);
	
}
