package cl.awakelab.Evaluacion_Modulo5.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.awakelab.Evaluacion_Modulo5.modelo.Pago;

public interface PagoRepository extends JpaRepository<Pago, Integer>{
	
}
