package cl.awakelab.Evaluacion_Modulo5.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.awakelab.Evaluacion_Modulo5.modelo.Rol;

public interface RolRepository extends JpaRepository<Rol, Integer>{
	
}
