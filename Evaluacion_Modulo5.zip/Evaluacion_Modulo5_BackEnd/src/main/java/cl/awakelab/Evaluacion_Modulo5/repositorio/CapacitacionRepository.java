package cl.awakelab.Evaluacion_Modulo5.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.awakelab.Evaluacion_Modulo5.modelo.Capacitacion;

public interface CapacitacionRepository extends JpaRepository<Capacitacion, Integer>{
	
}
