package cl.awakelab.Evaluacion_Modulo5.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.awakelab.Evaluacion_Modulo5.modelo.Acceso;

public interface AccesoRepository extends JpaRepository<Acceso, Integer>{
	
}
